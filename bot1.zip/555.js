const TelegramBot = require('node-telegram-bot-api');

// Вставь сюда токен, который дал BotFather
const token = '7575940779:AAGrj5cYHqwJFihemc2ca6dcISaEr7zuF4k';

// Создаем бота
const bot = new TelegramBot(token, { polling: true });

// Команда /start
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;

    bot.sendMessage(chatId, 'Привет! Запусти мини-приложение:', {
        reply_markup: {
            inline_keyboard: [
                [
                    {
                        text: "Открыть MiniApp",
                        web_app: { url: "https://soxrav.github.io/miniapp/" } // сюда вставь ссылку из GitHub Pages
                    }
                ]
            ]
        }
    });
});
